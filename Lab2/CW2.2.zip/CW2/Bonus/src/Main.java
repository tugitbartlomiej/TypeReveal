public class Main {

    public static void main(String[] args) throws Exception {
        //!!ZADANIE!! Wykorzystaj to co się nauczyłeś podczas tych zajęć żeby stworzyć prostą grę.
        // Możesz wykorzystać lanterna lub po prostu użyć terminał. Stwórz następujące klasy
        // Gracz, Klucz, Pokój, Skrzynia. Wykorzystaj Scanner lub screen.readinput() żeby sterować graczem.
        // Pokoje są za sobą połączone, klucze mogą otwierać dzrwi lub skrzynie. Stwórz osobne podklasy dla kluczy w
        // zależności co otwierają. Jak gracz otworzy skrzynię wygrywa.
        // Jak pokoje są połączone gdzie znajdują się klucze ty decydujesz.
    }
}